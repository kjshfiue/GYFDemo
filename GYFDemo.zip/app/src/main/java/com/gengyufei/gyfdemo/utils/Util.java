package com.gengyufei.gyfdemo.utils;

import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Created by FineFan on 2017/6/12.
 */

public class Util {


    public static String formatDate(long mills){
        SimpleDateFormat var1 = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        return var1.format(mills);
    }
}
